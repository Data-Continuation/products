from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
UNDERSCORE_PACKAGE = SRC / "core_lite"
HYPHEN_PACKAGE = SRC / "core-lite"

if not UNDERSCORE_PACKAGE.exists() and HYPHEN_PACKAGE.exists():
    shutil.copytree(HYPHEN_PACKAGE, UNDERSCORE_PACKAGE, ignore=shutil.ignore_patterns("__pycache__"))

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

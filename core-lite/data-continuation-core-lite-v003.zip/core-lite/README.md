# core-lite

Locked Data-Continuation `core-lite` bundle.

## Status

This bundle captures the current known-good repo shape that passed GitHub Actions after the runtime alias fix.

## Org Placement

```text
Data-Continuation/core-lite
Data-Continuation/products/core-lite
formalisms
formalism-tests
```

## Purpose

`core-lite` is the first runnable operational seed for the Data-Continuation Org.

It includes:

```text
ingestion -> CGE -> sandbox -> receipts
```

## Current Repo Path Contract

The current GitHub-visible source path is:

```text
src/core-lite
```

Python imports require:

```text
core_lite
```

Because Python cannot import a hyphenated package name directly, `tests/conftest.py` creates a runtime alias from:

```text
src/core-lite
```

to:

```text
src/core_lite
```

before tests import `core_lite`.

## Done Criteria

This repo is functional when:

1. `pytest -q` passes.
2. `python -m core_lite.cli ingest examples/allow.json --out out` returns `ALLOW`.
3. `python -m core_lite.cli ingest examples/deny.json --out out` returns `DENY`.
4. `python -m core_lite.cli ingest examples/sandbox.json --out out` returns `ALLOW` after sandbox approval.
5. Every ingest writes a canonical receipt to `out/receipts.jsonl`.
6. The GitHub Actions workflow passes.

## Install

```bash
python -m pip install -e ".[dev]"
```

## Test

```bash
pytest -q
```

## Run After Tests

The smoke commands work after pytest creates the runtime alias:

```bash
python -m core_lite.cli ingest examples/allow.json --out out
python -m core_lite.cli ingest examples/deny.json --out out
python -m core_lite.cli ingest examples/sandbox.json --out out
```

## Important Note

This is the locked passing state, not the final ideal path state.

The final ideal source path is still:

```text
src/core_lite
```

The current locked state intentionally preserves the repo path that is passing now:

```text
src/core-lite
```

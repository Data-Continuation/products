# Product Package Candidate: Data-Continuation Core-Lite v003

## Package Name

```text
data-continuation-core-lite-v003.zip
```

## Source Test Repo

```text
Data-Continuation/core-lite
```

## Future Product Location

```text
Data-Continuation/products/core-lite/data-continuation-core-lite-v003.zip
```

## Role

This package is the minimum runnable Data-Continuation core for SDK bootstrap, developer onboarding, and purchase-access delivery.

## Required Capabilities

```text
ingestion
CGE
sandbox
receipts
tests
CI
```

## Path Status

This package preserves the current passing repo path:

```text
src/core-lite
```

and includes the runtime alias in:

```text
tests/conftest.py
```

The ideal cleanup path for a later version is:

```text
src/core_lite
```

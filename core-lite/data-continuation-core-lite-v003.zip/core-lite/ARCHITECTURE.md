# core-lite Architecture

## Assumptions

1. The active source repo path is `Data-Continuation/core-lite`.
2. The product package path is `Data-Continuation/products/core-lite`.
3. `formalisms` and `formalism-tests` are separate orgs and should remain separate from this operational seed.
4. `core-lite` should not depend on a remote service, database, or external model.
5. The first admissibility gate should fail closed.
6. Receipts must be emitted for every evaluated input.
7. Sandbox routing is included as a local deterministic path, not as a permissive bypass.
8. The repository name may contain a hyphen, but the importable Python package must use an underscore: `core_lite`.

## Done Definition

`core-lite` is done for the standalone v002 seed when it can:

1. Accept a JSON input.
2. Normalize the input into a canonical ingestion envelope.
3. Evaluate the envelope through CGE.
4. Return `ALLOW`, `DENY`, or `SANDBOX`.
5. Execute sandbox review for `SANDBOX` decisions.
6. Emit an append-only receipt with hash chaining.
7. Pass local tests and CI tests.

## Boundary Model

```text
input JSON
  -> ingestion envelope
  -> CGE evaluation
  -> optional sandbox review
  -> final decision
  -> receipt append
```

## Minimal Decision Semantics

`ALLOW` means the normalized input satisfies required fields and does not exceed configured risk limits.

`DENY` means the input violates a hard constraint.

`SANDBOX` means the input is structurally valid but requires isolated review before it may continue.

`FAIL_CLOSED` is the default fallback whenever parsing, normalization, or evaluation fails.

## Ingestion Contract

Input may be either a full record:

```json
{
  "source": "example.allow",
  "payload": {
    "action": "continue",
    "risk": 0.1
  },
  "metadata": {}
}
```

or a direct payload object:

```json
{
  "action": "continue",
  "risk": 0.1
}
```

The ingestion layer normalizes both into:

```text
IngestionEnvelope(source, payload, metadata, input_hash)
```

## CGE Contract

CGE accepts an `IngestionEnvelope` and returns:

```text
Evaluation(decision, risk_score, reasons)
```

The first hard constraints are:

```text
missing required action -> FAIL_CLOSED
denied action -> DENY
risk >= deny threshold -> DENY
risk >= sandbox threshold -> SANDBOX
otherwise -> ALLOW
```

## Relationship To Formalism Orgs

`formalisms` should hold canonical math/spec repositories.

`formalism-tests` should hold formalism-specific test harness repositories.

`Data-Continuation/core-lite` should consume formalism outputs later, but this seed remains independent so it can bootstrap before richer imports exist.

## Extension Points

Future layers can extend without breaking this seed by adding:

- GCAT/BCAT state checks;
- Triad checks;
- inference-window checks;
- transition-periodic-table labels;
- remote attestation;
- multi-node receipt verification;
- replay/reconstruction tooling.

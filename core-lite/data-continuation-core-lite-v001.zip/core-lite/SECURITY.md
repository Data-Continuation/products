# Security Notes

## Core Principle

No local core-lite state may be exported, synced, imported, or connected to StegVerse unless TVC validates the authority boundary and the receipt chain verifies.

## Local-First Scope

Core-lite v001 is local-first. It does not require network access, cloud storage, live LLM provider calls, or production secret vaults.

## Secret Handling

Core-lite rejects raw secret values in records and policies. Use `secret_ref`, not `secret`.

## Connection Boundary

The `connection-check` command is a dry-run boundary check. It does not perform network communication. It validates whether an export manifest would be eligible for future connection.

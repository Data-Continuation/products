from __future__ import annotations

from .policy import CGEPolicy


def _risk(payload: dict, policy: CGEPolicy) -> float:
    try:
        risk = float(payload.get("risk", 0.0))
    except (TypeError, ValueError):
        return 1.0

    if str(payload.get("action", "unknown")) in policy.sandbox_actions:
        risk = max(risk, policy.sandbox_risk_threshold)
    return max(0.0, min(1.0, risk))


def evaluate_cge(envelope, tvc_result: dict, formalism_result: dict, policy: CGEPolicy | None = None) -> dict:
    cfg = policy or CGEPolicy()
    reasons: list[str] = []

    if tvc_result.get("decision") != "ALLOW":
        return {"decision": "FAIL_CLOSED", "risk_score": 1.0, "reasons": ["TVC boundary failed."] + tvc_result.get("reasons", [])}

    if formalism_result.get("decision") != "ALLOW":
        return {"decision": "FAIL_CLOSED", "risk_score": 1.0, "reasons": ["Formalism boundary failed."] + formalism_result.get("reasons", [])}

    if "action" not in envelope.payload:
        return {"decision": "FAIL_CLOSED", "risk_score": 1.0, "reasons": ["Missing required action."]}

    action = str(envelope.payload.get("action", "unknown"))
    if action in cfg.denied_actions:
        return {"decision": "DENY", "risk_score": 1.0, "reasons": [f"Action is denied by hard constraint: {action}"]}

    risk_score = _risk(envelope.payload, cfg)
    reasons.append(f"Computed risk score: {risk_score:.2f}")

    if risk_score >= cfg.deny_risk_threshold:
        return {"decision": "DENY", "risk_score": risk_score, "reasons": reasons + ["Risk score exceeds deny threshold."]}

    if risk_score >= cfg.sandbox_risk_threshold or action in cfg.sandbox_actions:
        return {"decision": "SANDBOX", "risk_score": risk_score, "reasons": reasons + ["Record requires sandbox review."]}

    return {"decision": "ALLOW", "risk_score": risk_score, "reasons": reasons + ["CGE passed."]}

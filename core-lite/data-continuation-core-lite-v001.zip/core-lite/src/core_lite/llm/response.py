from __future__ import annotations

from core_lite.utils import canonical_json, sha256_text


def normalize_llm_response(value: dict) -> dict:
    response = value.get("response", "")
    result = dict(value)
    result["response"] = str(response)
    result["response_hash"] = sha256_text(canonical_json({"response": result["response"], "model_ref": result.get("model_ref")}))
    return result

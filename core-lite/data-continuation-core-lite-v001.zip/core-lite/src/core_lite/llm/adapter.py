class LLMAdapter:
    provider = "abstract"

    def complete(self, request: dict) -> dict:
        raise NotImplementedError

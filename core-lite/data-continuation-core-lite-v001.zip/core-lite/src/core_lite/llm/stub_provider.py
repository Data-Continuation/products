from __future__ import annotations

from .request import normalize_llm_request
from .response import normalize_llm_response


def stub_complete(value: dict) -> dict:
    request = normalize_llm_request(value)
    if request.get("decision") != "ALLOW":
        return request
    response = {
        **request,
        "response": "StegVerse-managed stub response: assumptions stated, authority checked, continuation requires gate review.",
    }
    return normalize_llm_response(response)

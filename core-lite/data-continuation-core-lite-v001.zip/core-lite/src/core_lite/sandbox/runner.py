from __future__ import annotations


def run_sandbox(envelope, cge_result: dict) -> dict:
    decision = cge_result.get("decision")
    reasons = list(cge_result.get("reasons", []))
    risk_score = float(cge_result.get("risk_score", 1.0))

    if decision in ("DENY", "FAIL_CLOSED", "ALLOW"):
        return dict(cge_result)

    if decision != "SANDBOX":
        return {"decision": "FAIL_CLOSED", "risk_score": 1.0, "reasons": reasons + ["Unknown CGE decision."]}

    if envelope.metadata.get("sandbox_approved") is True and risk_score < 0.80:
        return {"decision": "ALLOW", "risk_score": risk_score, "reasons": reasons + ["Sandbox approved deterministic continuation."]}

    return {"decision": "DENY", "risk_score": risk_score, "reasons": reasons + ["Sandbox approval missing; fail closed."]}

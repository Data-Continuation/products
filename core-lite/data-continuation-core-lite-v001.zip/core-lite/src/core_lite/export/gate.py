def export_gate(receipt_verification: dict, tvc_result: dict) -> dict:
    if not receipt_verification.get("valid"):
        return {"decision": "FAIL_CLOSED", "reasons": ["Receipt chain must verify before export."]}
    if tvc_result.get("decision") != "ALLOW":
        return {"decision": "FAIL_CLOSED", "reasons": ["TVC boundary must pass before export."]}
    return {"decision": "ALLOW", "reasons": ["Export gate passed."]}

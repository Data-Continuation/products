from __future__ import annotations

import shutil
from pathlib import Path

from core_lite.receipts.verifier import verify_receipts
from core_lite.tvc.validator import validate_tvc
from core_lite.utils import write_json
from .gate import export_gate
from .manifest import export_manifest


def export_bundle(source_dir: str | Path, out_dir: str | Path) -> dict:
    source = Path(source_dir)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    receipts = source / "receipts.jsonl"
    receipt_verification = verify_receipts(receipts)
    tvc_result = validate_tvc({"authority_ref": "auth:user:local", "policy_ref": "policy:default"})
    gate = export_gate(receipt_verification, tvc_result)

    manifest = export_manifest(str(source), receipt_verification, tvc_result)
    manifest["gate"] = gate

    if gate["decision"] == "ALLOW":
        export_records = out / "records"
        export_records.mkdir(exist_ok=True)
        if receipts.exists():
            shutil.copyfile(receipts, out / "receipts.jsonl")

    write_json(out / "export_manifest.json", manifest)
    return manifest

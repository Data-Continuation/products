from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .ingestion import canonical_json, sha256_text
from .schemas import Evaluation, IngestionEnvelope, Receipt


def append_receipt(out_dir: str | Path, envelope: IngestionEnvelope, evaluation: Evaluation) -> Receipt:
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    receipts_path = path / "receipts.jsonl"

    previous_hash = _last_receipt_hash(receipts_path)
    timestamp = datetime.now(timezone.utc).isoformat()

    body = {
        "receipt_version": "core-lite.v1",
        "timestamp_utc": timestamp,
        "source": envelope.source,
        "input_hash": envelope.input_hash,
        "decision": evaluation.decision,
        "risk_score": evaluation.risk_score,
        "reasons": evaluation.reasons,
        "previous_receipt_hash": previous_hash,
    }
    receipt_hash = sha256_text(canonical_json(body))
    receipt = Receipt(receipt_hash=receipt_hash, **body)

    with receipts_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(asdict(receipt), sort_keys=True, ensure_ascii=False) + "\n")

    return receipt


def _last_receipt_hash(path: Path) -> str | None:
    if not path.exists():
        return None

    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        return None

    last = json.loads(lines[-1])
    value = last.get("receipt_hash")
    return value if isinstance(value, str) else None

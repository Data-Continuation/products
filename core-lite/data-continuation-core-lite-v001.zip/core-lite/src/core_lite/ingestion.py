from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .schemas import IngestionEnvelope


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def load_json_file(path: str | Path) -> dict[str, Any]:
    raw = Path(path).read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("Input JSON must be an object.")
    return data


def ingest(data: dict[str, Any]) -> IngestionEnvelope:
    source = str(data.get("source", "unknown"))
    payload = data.get("payload", data)
    metadata = data.get("metadata", {})

    if not isinstance(payload, dict):
        raise ValueError("Payload must be an object.")
    if not isinstance(metadata, dict):
        raise ValueError("Metadata must be an object.")

    input_hash = sha256_text(canonical_json({"source": source, "payload": payload, "metadata": metadata}))
    return IngestionEnvelope(
        source=source,
        payload=payload,
        metadata=metadata,
        input_hash=input_hash,
    )

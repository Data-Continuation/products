from __future__ import annotations

from .config import CoreLiteConfig
from .schemas import Evaluation, IngestionEnvelope


def review(envelope: IngestionEnvelope, evaluation: Evaluation, config: CoreLiteConfig | None = None) -> Evaluation:
    cfg = config or CoreLiteConfig()

    if evaluation.decision in ("DENY", "FAIL_CLOSED"):
        return evaluation

    if evaluation.decision != "SANDBOX":
        return evaluation

    action = str(envelope.payload.get("action", "unknown"))
    reasons = list(evaluation.reasons)

    if envelope.metadata.get("sandbox_approved") is True and evaluation.risk_score < cfg.deny_risk_threshold:
        return Evaluation("ALLOW", evaluation.risk_score, reasons + ["Sandbox approved deterministic continuation."])

    if action == "unknown":
        return Evaluation("DENY", evaluation.risk_score, reasons + ["Sandbox denied unknown action."])

    return Evaluation("DENY", evaluation.risk_score, reasons + ["Sandbox approval missing; fail closed."])

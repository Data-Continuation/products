from __future__ import annotations

from pathlib import Path

from core_lite.capabilities import capability_manifest
from core_lite.connection.boundary import connection_check
from core_lite.continuation.pipeline import run_continuation
from core_lite.export.bundle import export_bundle
from core_lite.llm.gate import llm_gate
from core_lite.llm.managed_assistant import assistant_preview
from core_lite.receipts.playback import playback_receipts
from core_lite.receipts.verifier import verify_receipts
from core_lite.storage.local import put_artifact
from core_lite.tvc.validator import validate_tvc
from core_lite.utils import write_json


def run_selftest(out_dir: str | Path) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    pipeline = run_continuation("examples/sandbox.json", out)
    receipts_path = out / "receipts.jsonl"
    receipt_verify = verify_receipts(receipts_path)
    playback = playback_receipts(receipts_path)
    export = export_bundle(out, out / "export")
    connection = connection_check(str(out / "export" / "export_manifest.json"))
    llm = llm_gate({
        "provider": "external-paste",
        "model_ref": "user:chosen-llm",
        "prompt": "Draft a legal reply.",
        "response": "Send this legal response immediately.",
        "metadata": {"domain": "legal"},
    })
    assistant = assistant_preview({"request": "Draft a careful legal reply.", "metadata": {"domain": "legal"}})
    storage = put_artifact("examples/allow.json", out)
    tvc = validate_tvc({"authority_ref": "auth:user:local", "policy_ref": "policy:default"})

    report = {
        "decision": "ALLOW" if all([
            pipeline["decision"] == "ALLOW",
            receipt_verify["valid"],
            playback["decision"] == "ALLOW",
            export["decision"] == "ALLOW",
            connection["decision"] == "ALLOW",
            llm["decision"] == "SANDBOX",
            assistant["decision"] == "SANDBOX",
            storage["decision"] == "ALLOW",
            tvc["decision"] == "ALLOW",
        ]) else "FAIL_CLOSED",
        "capabilities": capability_manifest(),
        "pipeline": pipeline["decision"],
        "receipt_verify": receipt_verify,
        "playback_steps": len(playback["timeline"]),
        "export": export["decision"],
        "connection": connection["decision"],
        "llm_gate": llm["decision"],
        "assistant": assistant["decision"],
        "storage": storage["decision"],
        "tvc": tvc["decision"],
    }
    write_json(out / "selftest_report.json", report)
    return report

def connection_result(decision: str, reasons: list[str]) -> dict:
    return {'decision': decision, 'reasons': reasons}

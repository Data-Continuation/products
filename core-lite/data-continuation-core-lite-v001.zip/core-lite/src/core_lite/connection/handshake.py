def dry_run_handshake(export_manifest: dict) -> dict:
    return {"decision": export_manifest.get("decision", "FAIL_CLOSED"), "mode": "dry-run"}

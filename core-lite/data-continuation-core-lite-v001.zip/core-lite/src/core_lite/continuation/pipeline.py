from __future__ import annotations

from pathlib import Path

from core_lite.cge.engine import evaluate_cge
from core_lite.formalisms.data_continuation import evaluate_data_continuation
from core_lite.ingestion.normalize import normalize_input
from core_lite.receipts.writer import append_receipt
from core_lite.sandbox.runner import run_sandbox
from core_lite.stegdb.local import put_record
from core_lite.storage.local import put_artifact
from core_lite.tvc.validator import validate_tvc
from core_lite.utils import read_json


def run_continuation(input_path: str, out_dir: str | Path) -> dict:
    data = read_json(input_path)
    envelope = normalize_input(data)
    tvc_result = validate_tvc({"metadata": envelope.metadata, "payload": envelope.payload})
    formalism = evaluate_data_continuation(envelope, tvc_result).to_dict()
    cge = evaluate_cge(envelope, tvc_result, formalism)
    final = run_sandbox(envelope, cge)

    record = put_record({
        "envelope": envelope.to_dict(),
        "tvc": tvc_result,
        "formalism": formalism,
        "cge": cge,
        "final": final,
    }, out_dir)

    artifact = put_artifact(input_path, out_dir)

    receipt = append_receipt(
        out_dir=out_dir,
        event_type="continuation.run",
        decision=final["decision"],
        subject_hash=envelope.input_hash,
        details={
            "record_hash": record["record_hash"],
            "object_hash": artifact.get("object_hash"),
            "tvc": tvc_result,
            "formalism": formalism,
            "cge": cge,
            "final": final,
        },
    )

    return {
        "decision": final["decision"],
        "envelope": envelope.to_dict(),
        "tvc": tvc_result,
        "formalism": formalism,
        "cge": cge,
        "final": final,
        "record": record,
        "artifact": artifact,
        "receipt": receipt,
    }

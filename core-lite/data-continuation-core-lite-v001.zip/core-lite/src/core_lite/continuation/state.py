def initial_state(project: str) -> dict:
    return {"project": project, "state": "initialized"}

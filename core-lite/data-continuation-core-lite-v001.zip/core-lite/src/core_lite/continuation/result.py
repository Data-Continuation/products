def continuation_result(**kwargs) -> dict:
    return kwargs

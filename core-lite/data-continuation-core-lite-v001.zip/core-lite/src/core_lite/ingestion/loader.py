from __future__ import annotations

from pathlib import Path
from typing import Any

from core_lite.utils import read_json


def load_json_file(path: str | Path) -> dict[str, Any]:
    return read_json(path)

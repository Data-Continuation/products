from __future__ import annotations

DEFAULT_POLICY_REF = "policy:default"
DEFAULT_AUTHORITY_REF = "auth:user:local"

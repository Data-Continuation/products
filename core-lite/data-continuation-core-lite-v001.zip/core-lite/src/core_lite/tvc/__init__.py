from .validator import validate_tvc

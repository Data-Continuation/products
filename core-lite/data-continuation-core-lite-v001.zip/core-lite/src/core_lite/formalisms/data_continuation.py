from __future__ import annotations

from .result import FormalismResult


def evaluate_data_continuation(envelope, tvc_result: dict) -> FormalismResult:
    constraints = ["input_shape", "authority_reference", "continuation_validity", "local_recoverability"]

    if tvc_result.get("decision") != "ALLOW":
        return FormalismResult(
            formalism_id="data-continuation.v1",
            decision="FAIL_CLOSED",
            confidence=1.0,
            reasons=["TVC boundary did not pass."],
            constraints_checked=constraints,
        )

    if "action" not in envelope.payload:
        return FormalismResult(
            formalism_id="data-continuation.v1",
            decision="FAIL_CLOSED",
            confidence=1.0,
            reasons=["Missing action prevents continuation."],
            constraints_checked=constraints,
        )

    return FormalismResult(
        formalism_id="data-continuation.v1",
        decision="ALLOW",
        confidence=1.0,
        reasons=["Data-Continuation local formalism passed."],
        constraints_checked=constraints,
    )

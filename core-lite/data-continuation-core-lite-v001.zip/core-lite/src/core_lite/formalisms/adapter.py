class FormalismAdapter:
    formalism_id = "abstract"

    def evaluate(self, envelope, tvc_result):
        raise NotImplementedError

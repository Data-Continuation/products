from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FormalismResult:
    formalism_id: str
    decision: str
    confidence: float
    reasons: list[str]
    constraints_checked: list[str]

    def to_dict(self) -> dict:
        return {
            "formalism_id": self.formalism_id,
            "decision": self.decision,
            "confidence": self.confidence,
            "reasons": self.reasons,
            "constraints_checked": self.constraints_checked,
        }

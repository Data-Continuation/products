from __future__ import annotations

from core_lite.utils import canonical_json, sha256_text


def receipt_hash(body: dict) -> str:
    return sha256_text(canonical_json(body))

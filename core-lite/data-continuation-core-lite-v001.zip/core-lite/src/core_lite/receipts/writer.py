from __future__ import annotations

import json
from pathlib import Path

from core_lite.utils import now_utc
from .chain import receipt_hash


def _last_hash(path: Path) -> str | None:
    if not path.exists():
        return None
    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not lines:
        return None
    return json.loads(lines[-1]).get("receipt_hash")


def append_receipt(out_dir: str | Path, event_type: str, decision: str, subject_hash: str, details: dict) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "receipts.jsonl"

    body = {
        "receipt_version": "core-lite.v001",
        "timestamp_utc": now_utc(),
        "event_type": event_type,
        "decision": decision,
        "subject_hash": subject_hash,
        "details": details,
        "previous_receipt_hash": _last_hash(path),
    }
    body["receipt_hash"] = receipt_hash(body)

    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(body, sort_keys=True, ensure_ascii=False) + "\n")

    return body

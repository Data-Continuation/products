CAPABILITIES = {
    "ingestion.v1": True,
    "tvc_boundary.v1": True,
    "formalism_boundary.v1": True,
    "cge.v1": True,
    "sandbox.v1": True,
    "receipts_record.v1": True,
    "receipts_playback.v1": True,
    "receipt_verify.v1": True,
    "stegdb_local.v1": True,
    "storage_local.v1": True,
    "llm_gate.v1": True,
    "personal_ai_assistant_preview.v1": True,
    "continuation_pipeline.v1": True,
    "export_gate.v1": True,
    "connection_boundary.v1": True,
    "product_selftest.v1": True,
}


def capability_manifest() -> dict:
    return {
        "capabilities": CAPABILITIES,
        "all_enabled": all(CAPABILITIES.values()),
    }

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Decision = Literal["ALLOW", "DENY", "SANDBOX", "FAIL_CLOSED"]


@dataclass(frozen=True)
class IngestionEnvelope:
    source: str
    payload: dict[str, Any]
    metadata: dict[str, Any]
    input_hash: str


@dataclass(frozen=True)
class Evaluation:
    decision: Decision
    risk_score: float
    reasons: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Receipt:
    receipt_version: str
    timestamp_utc: str
    source: str
    input_hash: str
    decision: Decision
    risk_score: float
    reasons: list[str]
    previous_receipt_hash: str | None
    receipt_hash: str

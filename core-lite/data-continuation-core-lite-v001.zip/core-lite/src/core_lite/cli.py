from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from .cge import evaluate
from .ingestion import ingest, load_json_file
from .receipts import append_receipt
from .sandbox import review


def run_ingest(path: str, out_dir: str) -> dict:
    data = load_json_file(path)
    envelope = ingest(data)
    initial = evaluate(envelope)
    final = review(envelope, initial)
    receipt = append_receipt(out_dir, envelope, final)

    return {
        "decision": final.decision,
        "risk_score": final.risk_score,
        "reasons": final.reasons,
        "receipt": asdict(receipt),
    }


def main() -> None:
    parser = argparse.ArgumentParser(prog="core-lite")
    sub = parser.add_subparsers(dest="command", required=True)

    ingest_parser = sub.add_parser("ingest")
    ingest_parser.add_argument("path")
    ingest_parser.add_argument("--out", default="out")

    args = parser.parse_args()

    if args.command == "ingest":
        result = run_ingest(args.path, args.out)
        print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

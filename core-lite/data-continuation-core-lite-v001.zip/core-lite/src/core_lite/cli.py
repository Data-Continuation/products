from __future__ import annotations

import argparse
import json
from pathlib import Path

from core_lite.capabilities import capability_manifest
from core_lite.cge.engine import evaluate_cge
from core_lite.connection.boundary import connection_check
from core_lite.continuation.pipeline import run_continuation
from core_lite.export.bundle import export_bundle
from core_lite.formalisms.data_continuation import evaluate_data_continuation
from core_lite.ingestion.loader import load_json_file
from core_lite.ingestion.normalize import normalize_input
from core_lite.llm.gate import llm_gate
from core_lite.llm.managed_assistant import assistant_preview
from core_lite.product.selftest import run_selftest
from core_lite.receipts.playback import playback_receipts
from core_lite.receipts.verifier import verify_receipts
from core_lite.stegdb.local import get_record, put_record
from core_lite.storage.local import put_artifact
from core_lite.storage.verifier import verify_object_ref
from core_lite.tvc.validator import validate_tvc
from core_lite.utils import write_json


def print_json(value: dict) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser(prog="core-lite")
    sub = parser.add_subparsers(dest="command", required=True)

    project_init = sub.add_parser("project-init")
    project_init.add_argument("name")
    project_init.add_argument("--out", default="out")

    ingest = sub.add_parser("ingest")
    ingest.add_argument("input")

    tvc = sub.add_parser("tvc-check")
    tvc.add_argument("input")

    formalism = sub.add_parser("formalism")
    formalism.add_argument("input")

    cge = sub.add_parser("cge")
    cge.add_argument("input")

    llm_gate_parser = sub.add_parser("llm-gate")
    llm_gate_parser.add_argument("input")

    assistant = sub.add_parser("assistant")
    assistant.add_argument("input")
    assistant.add_argument("--out", default="out")

    run = sub.add_parser("run")
    run.add_argument("input")
    run.add_argument("--out", default="out")

    record = sub.add_parser("record")
    record.add_argument("input")
    record.add_argument("--out", default="out")

    playback = sub.add_parser("playback")
    playback.add_argument("receipts")

    verify = sub.add_parser("verify-receipts")
    verify.add_argument("receipts")

    stegdb_put = sub.add_parser("stegdb-put")
    stegdb_put.add_argument("input")
    stegdb_put.add_argument("--out", default="out")

    stegdb_get = sub.add_parser("stegdb-get")
    stegdb_get.add_argument("record_hash")
    stegdb_get.add_argument("--out", default="out")

    storage_put = sub.add_parser("storage-put")
    storage_put.add_argument("path")
    storage_put.add_argument("--out", default="out")

    storage_verify = sub.add_parser("storage-verify")
    storage_verify.add_argument("object_ref")

    export = sub.add_parser("export")
    export.add_argument("source")
    export.add_argument("--out", default="export")

    conn = sub.add_parser("connection-check")
    conn.add_argument("export_manifest")

    selftest = sub.add_parser("selftest")
    selftest.add_argument("--out", default="out")

    caps = sub.add_parser("capabilities")

    args = parser.parse_args()

    if args.command == "project-init":
        project_dir = Path(args.out) / args.name
        project_dir.mkdir(parents=True, exist_ok=True)
        result = {"decision": "ALLOW", "project": args.name, "path": str(project_dir)}
        write_json(project_dir / "project_manifest.json", result)
    elif args.command == "ingest":
        result = normalize_input(load_json_file(args.input)).to_dict()
    elif args.command == "tvc-check":
        result = validate_tvc(load_json_file(args.input))
    elif args.command == "formalism":
        envelope = normalize_input(load_json_file(args.input))
        tvc_result = validate_tvc({"metadata": envelope.metadata, "payload": envelope.payload})
        result = evaluate_data_continuation(envelope, tvc_result).to_dict()
    elif args.command == "cge":
        envelope = normalize_input(load_json_file(args.input))
        tvc_result = validate_tvc({"metadata": envelope.metadata, "payload": envelope.payload})
        formalism_result = evaluate_data_continuation(envelope, tvc_result).to_dict()
        result = evaluate_cge(envelope, tvc_result, formalism_result)
    elif args.command == "llm-gate":
        result = llm_gate(load_json_file(args.input))
    elif args.command == "assistant":
        result = assistant_preview(load_json_file(args.input))
        write_json(Path(args.out) / "assistant_preview.json", result)
    elif args.command in ("run", "record"):
        result = run_continuation(args.input, args.out)
    elif args.command == "playback":
        result = playback_receipts(args.receipts)
    elif args.command == "verify-receipts":
        result = verify_receipts(args.receipts)
    elif args.command == "stegdb-put":
        result = put_record(load_json_file(args.input), args.out)
    elif args.command == "stegdb-get":
        result = get_record(args.record_hash, args.out)
    elif args.command == "storage-put":
        result = put_artifact(args.path, args.out)
    elif args.command == "storage-verify":
        result = verify_object_ref(args.object_ref)
    elif args.command == "export":
        result = export_bundle(args.source, args.out)
    elif args.command == "connection-check":
        result = connection_check(args.export_manifest)
    elif args.command == "selftest":
        result = run_selftest(args.out)
    elif args.command == "capabilities":
        result = capability_manifest()
    else:
        raise SystemExit(f"Unsupported command: {args.command}")

    print_json(result)


if __name__ == "__main__":
    main()

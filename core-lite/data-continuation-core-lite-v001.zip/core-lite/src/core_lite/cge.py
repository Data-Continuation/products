from __future__ import annotations

from .config import CoreLiteConfig
from .schemas import Evaluation, IngestionEnvelope


def evaluate(envelope: IngestionEnvelope, config: CoreLiteConfig | None = None) -> Evaluation:
    cfg = config or CoreLiteConfig()
    reasons: list[str] = []

    missing = [key for key in cfg.required_payload_keys if key not in envelope.payload]
    if missing:
        return Evaluation("FAIL_CLOSED", 1.0, [f"Missing required payload keys: {', '.join(missing)}"])

    if len(envelope.payload) > cfg.max_payload_keys:
        return Evaluation("DENY", 1.0, ["Payload exceeds maximum key count."])

    action = str(envelope.payload.get("action", "unknown"))
    if action in cfg.denied_actions:
        return Evaluation("DENY", 1.0, [f"Action is denied by hard constraint: {action}"])

    risk_score = _risk_score(envelope, cfg)
    reasons.append(f"Computed risk score: {risk_score:.2f}")

    if risk_score >= cfg.deny_risk_threshold:
        return Evaluation("DENY", risk_score, reasons + ["Risk score exceeds deny threshold."])

    if risk_score >= cfg.sandbox_risk_threshold or action in cfg.sandbox_actions:
        return Evaluation("SANDBOX", risk_score, reasons + ["Record requires sandbox review."])

    return Evaluation("ALLOW", risk_score, reasons + ["Record satisfies core-lite constraints."])


def _risk_score(envelope: IngestionEnvelope, cfg: CoreLiteConfig) -> float:
    action = str(envelope.payload.get("action", "unknown"))
    declared_risk = envelope.payload.get("risk", 0.0)

    try:
        risk = float(declared_risk)
    except (TypeError, ValueError):
        risk = 1.0

    if action in cfg.sandbox_actions:
        risk = max(risk, cfg.sandbox_risk_threshold)

    if envelope.metadata.get("untrusted") is True:
        risk = max(risk, 0.70)

    return max(0.0, min(1.0, risk))

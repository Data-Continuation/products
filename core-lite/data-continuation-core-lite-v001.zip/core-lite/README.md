# core-lite

Clean v001 repository bundle for `Data-Continuation/core-lite`.

## Assumptions

1. This bundle is intended for a clean repo upload.
2. The importable Python package path is `src/core_lite`.
3. There is no `src/core-lite` runtime alias.
4. This is a normal-user StegVerse onboarding substrate, not just a developer SDK.
5. Every capability is local-first, deterministic, and device/platform agnostic.
6. No live LLM provider is required by default.
7. TVC acts as the prevention buffer before local state can connect outward to StegVerse.

## What this bundle lets a normal user do

A user can:

```text
start a StegVerse-ready local project
add files, notes, AI outputs, and decisions
compare unmanaged LLM output to StegVerse-managed AI behavior
decide whether outputs may enter continuing state
record receipts
play back what happened
verify whether receipts were altered
prepare export bundles only after TVC and receipt validation
```

## Core flow

```text
input
  -> ingestion
  -> TVC boundary validation
  -> formalism evaluation
  -> optional LLM Gate
  -> CGE
  -> sandbox
  -> StegDB local canonical record
  -> Steg Storage local artifact refs
  -> receipt recording
  -> playback-ready event log
  -> export gate through TVC
```

## Done Criteria

This bundle is done when all of the following pass:

```text
pytest -q
core-lite selftest --out out
core-lite project-init demo --out out
core-lite ingest examples/allow.json
core-lite tvc-check examples/tvc_valid.json
core-lite formalism examples/allow.json
core-lite cge examples/allow.json
core-lite llm-gate examples/llm_sensitive_legal.json
core-lite assistant examples/personal_ai_assistant_request.json --out out
core-lite run examples/sandbox.json --out out
core-lite record examples/allow.json --out out
core-lite playback out/receipts.jsonl
core-lite verify-receipts out/receipts.jsonl
core-lite stegdb-put examples/allow.json --out out
core-lite storage-put examples/allow.json --out out
core-lite export out --out export
core-lite connection-check export/export_manifest.json
```

## Install

```bash
python -m pip install -e ".[dev]"
```

## Test

```bash
pytest -q
```

## Repository Shape

```text
README.md
ARCHITECTURE.md
PRODUCT.md
SECURITY.md
BUILD_VERIFICATION.json
manifest.json
pyproject.toml
examples/
src/core_lite/
tests/
.github/workflows/test.yml
```

Note: `.github/workflows/test.yml` is the actual GitHub Actions path. If displaying without a leading dot, write `github/workflows/test.yml` and note that the leading dot has been removed for display.

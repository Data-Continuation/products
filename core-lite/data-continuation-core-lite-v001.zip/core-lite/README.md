# core-lite

Standalone Data-Continuation `core-lite` repository package.

## Org Placement

```text
Data-Continuation/core-lite
formalisms
formalism-tests
```

## Purpose

`core-lite` is the first runnable operational seed for the Data-Continuation Org. It accepts incoming records, normalizes them, evaluates them through a conservative Commit Governance Engine, optionally routes uncertain records through a sandbox, and emits append-only receipts.

## Done Criteria

This repository is considered functional when:

1. `python -m core_lite.cli ingest examples/allow.json --out out` returns `ALLOW`.
2. `python -m core_lite.cli ingest examples/deny.json --out out` returns `DENY`.
3. `python -m core_lite.cli ingest examples/sandbox.json --out out` returns `ALLOW` after sandbox approval.
4. Every ingest writes a canonical receipt to `out/receipts.jsonl`.
5. `pytest` passes.
6. The GitHub Actions workflow passes.

## Install

```bash
python -m pip install -e ".[dev]"
```

## Run

```bash
python -m core_lite.cli ingest examples/allow.json --out out
python -m core_lite.cli ingest examples/deny.json --out out
python -m core_lite.cli ingest examples/sandbox.json --out out
```

## Test

```bash
pytest -q
```

## Repository Shape

```text
core-lite/
  README.md
  ARCHITECTURE.md
  BUILD_VERIFICATION.json
  pyproject.toml
  examples/
    allow.json
    deny.json
    sandbox.json
  src/
    core_lite/
      __init__.py
      cli.py
      config.py
      cge.py
      ingestion.py
      receipts.py
      sandbox.py
      schemas.py
  tests/
    conftest.py
    test_core_lite.py
  github/workflows/test.yml
```

Note: `github/workflows/test.yml` is displayed without the leading dot. The actual GitHub Actions path in the bundle is `.github/workflows/test.yml`.

## Important Python Path Note

The Python package folder must be:

```text
src/core_lite/
```

not:

```text
src/core-lite/
```

The repository may be named `core-lite`, but Python imports require the underscore package name `core_lite`.

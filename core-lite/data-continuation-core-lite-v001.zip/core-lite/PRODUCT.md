# Product: Data-Continuation Core-Lite v001

## Package Name

```text
data-continuation-core-lite-v001.zip
```

## Source Repo

```text
Data-Continuation/core-lite
```

## Product Location

```text
Data-Continuation/products/core-lite/data-continuation-core-lite-v001.zip
```

## User-Facing Product Identity

This bundle powers:

```text
StegBridge Lite
StegVerse LLM Gate
StegVerse Personal AI Assistant Preview
StegVerse Continuation Kit
StegLaunch Lite
StegContinuity Exporter
```

## Normal User Value

The user can start a local StegVerse-ready project, add records/files/AI outputs, govern whether those artifacts may continue, record receipts, play back what happened, and export only if TVC and receipt checks pass.

## Not Included in v001

```text
no production remote StegDB service
no cloud storage dependency
no production token minting
no raw secret storage
no live LLM provider required by default
no full GCAT/BCAT/Triad engine bundled
no payments
no auth system
no multi-node consensus
```

The required boundaries for those systems are included.

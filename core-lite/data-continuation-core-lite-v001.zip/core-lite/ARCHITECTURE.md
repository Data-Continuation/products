# core-lite Architecture

## Clean v001 Definition

`core-lite` is a local-first, device/platform agnostic StegVerse onboarding substrate that lets normal users experience governed LLM continuation, record and play back receipt-backed decisions, and prepare integration-ready exports while TVC acts as the prevention buffer between local state and the larger StegVerse ecosystem.

## Core Capabilities

```text
ingestion.v1
tvc_boundary.v1
formalism_boundary.v1
cge.v1
sandbox.v1
receipts_record.v1
receipts_playback.v1
receipt_verify.v1
stegdb_local.v1
storage_local.v1
llm_gate.v1
personal_ai_assistant_preview.v1
continuation_pipeline.v1
export_gate.v1
connection_boundary.v1
product_selftest.v1
```

## Boundary Model

```text
input JSON
  -> canonical ingestion envelope
  -> TVC authority boundary validation
  -> Data-Continuation formalism boundary
  -> LLM Gate if applicable
  -> Commit Governance Engine
  -> deterministic sandbox review
  -> local StegDB record
  -> local Steg Storage object refs
  -> receipt recording
  -> receipt playback / verification
  -> export and connection gate
```

## TVC Prevention Buffer

Core-lite does not mint production tokens or store raw secrets. It does enforce executable authority representation.

Rules:

```text
missing authority ref -> FAIL_CLOSED
missing policy ref -> FAIL_CLOSED
raw secret value -> DENY
valid refs -> ALLOW
export without TVC validation -> FAIL_CLOSED
connection without TVC validation -> FAIL_CLOSED
```

## Formalism Boundary

The default local formalism is:

```text
data-continuation.v1
```

It is not the full GCAT/BCAT/Triad engine. It is the required adapter boundary where GCAT/BCAT, ECAT/ICAT, Triad, Inference Window, and Transition Periodic Table engines can plug in later without changing the core pipeline.

## LLM Gate

The LLM adapter is a user-visible governance gate.

It lets a normal user compare:

```text
ordinary unmanaged LLM output
vs.
StegVerse-managed LLM continuation
```

v001 includes a deterministic local stub provider and adapter boundary. A live provider is not required by default.

## Receipt Recording and Playback

Receipt recording and playback are first-class v001 features.

Reconstruction is intentionally later, but playback lets a user or support inspect what happened without requiring full forensic reconstruction.

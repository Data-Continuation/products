# core-lite Architecture

## Assumptions

1. The active org/repo path is `Data-Continuation/core-lite`.
2. `formalisms` and `formalism-tests` are separate orgs and should remain separate from this operational seed.
3. `core-lite` should not depend on a remote service, database, or external model.
4. The first admissibility gate should fail closed.
5. Receipts must be emitted for every evaluated input.
6. Sandbox routing is included as a local deterministic path, not as a permissive bypass.
7. The repository name may contain a hyphen, but the importable Python package must use an underscore: `core_lite`.

## Done Definition

`core-lite` is done for the first standalone seed when it can:

1. Accept a JSON input.
2. Normalize the input into a canonical ingestion envelope.
3. Evaluate the envelope through CGE.
4. Return `ALLOW`, `DENY`, or `SANDBOX`.
5. Execute sandbox review for `SANDBOX` decisions.
6. Emit an append-only receipt with hash chaining.
7. Pass local tests and CI tests.

## Boundary Model

```text
input JSON
  -> ingestion envelope
  -> CGE evaluation
  -> optional sandbox review
  -> final decision
  -> receipt append
```

## Minimal Decision Semantics

`ALLOW` means the normalized input satisfies required fields and does not exceed configured risk limits.

`DENY` means the input violates a hard constraint.

`SANDBOX` means the input is structurally valid but requires isolated review before it may continue.

`FAIL_CLOSED` is the default internal fallback whenever parsing, normalization, or evaluation fails.

## Essential Modules

### ingestion

Responsible for:

- parsing JSON input;
- preserving source metadata;
- assigning deterministic input hashes;
- producing a normalized envelope.

### CGE

CGE stands for Commit Governance Engine.

Responsible for:

- enforcing hard constraints;
- computing a basic risk score;
- classifying the envelope as `ALLOW`, `DENY`, or `SANDBOX`;
- preserving decision reasons.

### sandbox

Responsible for:

- deterministic isolated review of records that are neither clearly allowed nor clearly denied;
- never upgrading a hard denial;
- producing a final decision and reason trail.

### receipts

Responsible for:

- append-only `receipts.jsonl`;
- canonical JSON serialization;
- receipt hash;
- previous receipt hash chaining.

## Relationship To Formalism Orgs

`formalisms` should hold canonical math/spec repositories.

`formalism-tests` should hold formalism-specific test harness repositories.

`Data-Continuation/core-lite` should consume formalism outputs later, but this seed remains independent so it can bootstrap before richer imports exist.

## Extension Points

Future layers can extend without breaking this seed by adding:

- GCAT/BCAT state checks;
- Triad checks;
- inference-window checks;
- transition-periodic-table labels;
- remote attestation;
- multi-node receipt verification;
- replay/reconstruction tooling.

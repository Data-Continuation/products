from pathlib import Path
import json

from core_lite.cge.engine import evaluate_cge
from core_lite.connection.boundary import connection_check
from core_lite.continuation.pipeline import run_continuation
from core_lite.export.bundle import export_bundle
from core_lite.formalisms.data_continuation import evaluate_data_continuation
from core_lite.ingestion.normalize import normalize_input
from core_lite.llm.gate import llm_gate
from core_lite.llm.managed_assistant import assistant_preview
from core_lite.product.selftest import run_selftest
from core_lite.receipts.playback import playback_receipts
from core_lite.receipts.verifier import verify_receipts
from core_lite.stegdb.local import get_record, put_record
from core_lite.storage.local import put_artifact
from core_lite.storage.verifier import verify_object_ref
from core_lite.tvc.validator import validate_tvc
from core_lite.utils import read_json


def test_ingestion_full_and_direct_payload() -> None:
    full = normalize_input(read_json("examples/allow.json"))
    direct = normalize_input({"action": "continue", "risk": 0.1})

    assert full.source == "example.allow"
    assert len(full.input_hash) == 64
    assert direct.source == "unknown"
    assert direct.payload["action"] == "continue"


def test_tvc_valid_missing_and_raw_secret() -> None:
    assert validate_tvc(read_json("examples/tvc_valid.json"))["decision"] == "ALLOW"
    assert validate_tvc(read_json("examples/tvc_missing_authority.json"))["decision"] == "FAIL_CLOSED"
    assert validate_tvc(read_json("examples/tvc_raw_secret.json"))["decision"] == "DENY"


def test_formalism_boundary() -> None:
    envelope = normalize_input(read_json("examples/allow.json"))
    tvc = validate_tvc({"metadata": envelope.metadata})
    result = evaluate_data_continuation(envelope, tvc).to_dict()

    assert result["formalism_id"] == "data-continuation.v1"
    assert result["decision"] == "ALLOW"


def test_cge_allow_deny_sandbox_fail_closed() -> None:
    allow = normalize_input(read_json("examples/allow.json"))
    deny = normalize_input(read_json("examples/deny.json"))
    sandbox = normalize_input(read_json("examples/sandbox.json"))
    missing = normalize_input(read_json("examples/missing_action.json"))

    for envelope, expected in [(allow, "ALLOW"), (deny, "DENY"), (sandbox, "SANDBOX"), (missing, "FAIL_CLOSED")]:
        tvc = validate_tvc({"metadata": envelope.metadata, "payload": envelope.payload})
        formalism = evaluate_data_continuation(envelope, tvc).to_dict()
        assert evaluate_cge(envelope, tvc, formalism)["decision"] == expected


def test_llm_gate_and_assistant_preview() -> None:
    gate = llm_gate(read_json("examples/llm_sensitive_legal.json"))
    assistant = assistant_preview(read_json("examples/personal_ai_assistant_request.json"))

    assert gate["decision"] == "SANDBOX"
    assert assistant["decision"] == "SANDBOX"
    assert "comparison" in assistant


def test_continuation_receipts_playback_and_verify(tmp_path: Path) -> None:
    result = run_continuation("examples/sandbox.json", tmp_path)
    receipts = tmp_path / "receipts.jsonl"
    verify = verify_receipts(receipts)
    playback = playback_receipts(receipts)

    assert result["decision"] == "ALLOW"
    assert verify["valid"] is True
    assert playback["decision"] == "ALLOW"
    assert playback["timeline"]


def test_receipt_tamper_detection(tmp_path: Path) -> None:
    run_continuation("examples/allow.json", tmp_path)
    receipts = tmp_path / "receipts.jsonl"
    original = receipts.read_text(encoding="utf-8")
    tampered = original.replace("ALLOW", "DENY", 1)
    receipts.write_text(tampered, encoding="utf-8")

    assert verify_receipts(receipts)["decision"] == "FAIL_CLOSED"


def test_stegdb_put_get_missing(tmp_path: Path) -> None:
    wrapped = put_record({"hello": "world"}, tmp_path)
    fetched = get_record(wrapped["record_hash"], tmp_path)
    missing = get_record("missing", tmp_path)

    assert fetched["decision"] == "ALLOW"
    assert missing["decision"] == "FAIL_CLOSED"


def test_storage_put_and_verify(tmp_path: Path) -> None:
    ref = put_artifact("examples/allow.json", tmp_path)
    ref_path = Path(ref["path"]).with_suffix("").with_suffix(".object_ref.json")
    # Find actual generated ref path since original suffix may be .json
    refs = list((tmp_path / "storage").glob("*.object_ref.json"))

    assert ref["decision"] == "ALLOW"
    assert verify_object_ref(refs[0])["valid"] is True


def test_export_and_connection_boundary(tmp_path: Path) -> None:
    run_continuation("examples/allow.json", tmp_path / "project")
    export = export_bundle(tmp_path / "project", tmp_path / "export")
    connection = connection_check(str(tmp_path / "export" / "export_manifest.json"))

    assert export["decision"] == "ALLOW"
    assert connection["decision"] == "ALLOW"


def test_selftest(tmp_path: Path) -> None:
    report = run_selftest(tmp_path)

    assert report["decision"] == "ALLOW"
    assert (tmp_path / "selftest_report.json").exists()

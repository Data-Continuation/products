from pathlib import Path

from core_lite.cli import run_ingest


def test_allow_emits_receipt(tmp_path: Path) -> None:
    result = run_ingest("examples/allow.json", str(tmp_path))

    assert result["decision"] == "ALLOW"
    assert (tmp_path / "receipts.jsonl").exists()


def test_deny_hard_constraint(tmp_path: Path) -> None:
    result = run_ingest("examples/deny.json", str(tmp_path))

    assert result["decision"] == "DENY"
    assert "hard constraint" in " ".join(result["reasons"])


def test_sandbox_can_approve_when_flagged(tmp_path: Path) -> None:
    result = run_ingest("examples/sandbox.json", str(tmp_path))

    assert result["decision"] == "ALLOW"
    assert "Sandbox approved" in " ".join(result["reasons"])


def test_receipt_hash_chains(tmp_path: Path) -> None:
    first = run_ingest("examples/allow.json", str(tmp_path))
    second = run_ingest("examples/deny.json", str(tmp_path))

    assert first["receipt"]["previous_receipt_hash"] is None
    assert second["receipt"]["previous_receipt_hash"] == first["receipt"]["receipt_hash"]
